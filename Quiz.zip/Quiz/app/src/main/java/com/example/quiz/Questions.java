package com.example.quiz;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Questions extends AppCompatActivity {
    ArrayList arrayList;
    JSONArray array;
    Context context;
    int pos=0;
    Map<String, String> mp=new HashMap<String, String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);
        context=this;
        displayQuestion();
    }

    public void displayQuestion(){
        TableLayout tableLayout=(TableLayout) findViewById(R.id.tbl);
        arrayList = new ArrayList<>();
        try {
            JSONObject object = new JSONObject(readJSON());
            array = object.getJSONArray("question");
            System.out.println("size "+array.length());
            for (int i = 0; i < array.length(); i++) {
                System.out.println("Setting Id "+i);
                JSONObject jsonObject = array.getJSONObject(i);
                String number = jsonObject.getString("number");
                String question = jsonObject.getString("question");
                final JSONArray answers =new JSONArray(jsonObject.getString("answers"));
                System.out.println("Id "+i+" answer "+answers);
                String correct_answer = jsonObject.getString("correct_answer");
                TableRow tableRow=new TableRow(this);
                TextView ques=new TextView(this);
                ques.setText(Integer.toString(i+1)+") "+question);
                ques.setTypeface(null, Typeface.BOLD);
                tableRow.addView(ques);
                tableLayout.addView(tableRow);

                TableRow option=new TableRow(this);
                RadioGroup rg=new RadioGroup(this);
                rg.setOrientation(RadioGroup.VERTICAL);
                System.out.println("Setting Id before "+i);
                rg.setId(i);
                for(int j=0;j<answers.length();j++){
                    final RadioButton rb=new RadioButton(this);
                    pos=j;
                    rb.setText(""+answers.get(j));
                    rb.setTextColor(Color.BLACK);
                    rb.setId(Integer.parseInt(number)+answers.length()+5-j);
                    rb.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            System.out.println("Click "+rb.getText());
                            try {
                                mp.put(answers.get(0).toString(), rb.getText().toString());
                            }catch (Exception e){
                                e.printStackTrace();
                            }
                        }
                    });
                    rg.addView(rb);

                }
                option.addView(rg);
                tableLayout.addView(option);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public String readJSON() {
        String json = null;
        try {
            // Opening data.json file
            InputStream inputStream = getAssets().open("quizQues.json");
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            // read values in the byte array
            inputStream.read(buffer);
            inputStream.close();
            // convert byte to string
            json = new String(buffer, "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
            return json;
        }
        return json;
    }

    public void check(View v){
        System.out.println("Mapping  "+mp);
        try {
            int count  =0;
            int inCor=0;
            int val=0;
            int btnid=0;
            System.out.println("size "+array.length());
            for (int i = 0; i < array.length(); i++) {
                JSONObject jsonObject = array.getJSONObject(i);
                String number = jsonObject.getString("number");
                JSONArray answers =new JSONArray(jsonObject.getString("answers"));
                String correct_answer = jsonObject.getString("correct_answer");
                System.out.println("Correct Ans dfs "+answers.get(Integer.parseInt(correct_answer)-1));
                RadioGroup rd=(RadioGroup) findViewById(i);
                btnid=rd.getCheckedRadioButtonId();

                RadioButton btn=(RadioButton) findViewById(btnid);
                System.out.println("Button Ids "+btn);
                /*
                System.out.println("Correct Ans  t/f "+btn.getText().toString().equals(answers.get(Integer.parseInt(correct_answer)-1).toString()));*/

                if(btn.isChecked()){
                    System.out.println("Selected Answer "+btn.getText());
                    if(btn.getText().toString().equals(answers.get(Integer.parseInt(correct_answer)-1).toString())){
                        count++;
                    }else {
                        inCor++;
                    }
                }

            }
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setTitle("Result");
            alertDialogBuilder.setMessage("Score : "+count);
            alertDialogBuilder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                    Intent intent=new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                }
            });
            AlertDialog al=alertDialogBuilder.create();
            al.show();
            System.out.println("Correct Answer "+count+" Not Correct "+inCor);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
